import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/models/product.dart';

class FavoritesProvider with ChangeNotifier {
  List<int> _favoriteProductIds = [];

  List<int> get favoriteProductIds => _favoriteProductIds;

  FavoritesProvider() {
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    _favoriteProductIds = prefs.getStringList('favorites')?.map(int.parse).toList() ?? [];
    notifyListeners();
  }

  Future<void> toggleFavorite(int productId) async {
    if (_favoriteProductIds.contains(productId)) {
      _favoriteProductIds.remove(productId);
    } else {
      _favoriteProductIds.add(productId);
    }
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        'favorites', _favoriteProductIds.map((id) => id.toString()).toList());
  }

  bool isFavorite(int productId) {
    return _favoriteProductIds.contains(productId);
  }

  void removeFavorite(int i) {}

  void addFavorite(Product product) {}
}
