import 'package:flutter/material.dart';

class ProductImageSlider extends StatelessWidget {
  final List<String> images;

  const ProductImageSlider({super.key, required this.images});

  @override
  Widget build(BuildContext context) {
    if (images.isEmpty) {
      return const SizedBox(height: 200, child: Center(child: Text('Pas d\'image')));
    }

    return SizedBox(
      height: 250,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: images.length,
        separatorBuilder: (context, index) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              images[index],
              height: 250,
              width: MediaQuery.of(context).size.width * 0.8,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image),
            ),
          );
        },
      ),
    );
  }
}
