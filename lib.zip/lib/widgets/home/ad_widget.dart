import 'dart:async';
import 'package:flutter/material.dart';

class AdWidget extends StatefulWidget {
  const AdWidget({super.key});

  final List<Map<String, String>> adsList = const [
    {"img": "ad.webp", "text": "Text01"},
    {"img": "ad2.webp", "text": "Text02"},
    {"img": "ad3.webp", "text": "Text03"},
  ];

  @override
  State<AdWidget> createState() => _AdWidgetState();
}

class _AdWidgetState extends State<AdWidget> {
  late PageController _pageController;
  int _currentPage = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (_currentPage < widget.adsList.length - 1) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }

      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return SizedBox(
      height: 260,
      child: PageView.builder(
        controller: _pageController,
        itemCount: widget.adsList.length,
        itemBuilder: (context, index) {
          final ad = widget.adsList[index];
          return Column(
            children: [
              Image.asset(
                'assets/images/${ad['img']}',
                width: screenWidth,
                height: 220,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 8),
              Text(ad['text'] ?? ''),
            ],
          );
        },
      ),
    );
  }
}
