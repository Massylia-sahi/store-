import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:store/models/product.dart';

class ApiService {
  // Récupère les produits d'une catégorie spécifique
  static Future<List<Product>> fetchProductsByCategory(int categoryId) async {
    final response = await http.get(
      Uri.parse('https://api.escuelajs.co/api/v1/products/?categoryId=$categoryId'),
    );
    final List data = jsonDecode(response.body);
    return data.map((json) => Product.fromJson(json)).toList();
  }

  // Récupère les détails d'un produit par son ID
  static Future<Product> fetchProductById(int id) async {
    final response = await http.get(
      Uri.parse('https://api.escuelajs.co/api/v1/products/$id'),
    );
    return Product.fromJson(jsonDecode(response.body));
  }

  static Future<List<Product>> getProductsByIds(List<int> ids) => throw UnimplementedError('getProductsByIds has not been implemented.');
}
