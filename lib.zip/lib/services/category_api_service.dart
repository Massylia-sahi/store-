import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:store/models/category.dart';
import 'package:store/models/product.dart';

class CategoryApiService {
  static const String baseUrl = 'https://api.escuelajs.co/api/v1';

  /// Récupère toutes les catégories depuis l'API.
  Future<List<Category>> getCategories() async {
    final Uri url = Uri.parse('$baseUrl/categories');

    final http.Response response = await http.get(url);

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);

      return data.map<Category>((category) {
        return Category(
          id: category['id'],
          name: category['name'],
          slug: category['slug'],
          image: category['image'],
        );
      }).toList();
    } else {
      throw Exception('Erreur lors de la récupération des catégories');
    }
  }

  /// Récupère la liste des produits d'une catégorie donnée par son [categoryId].
  Future<List<Product>> getProductsByCategoryId(int categoryId) async {
    final Uri url = Uri.parse('$baseUrl/categories/$categoryId/products');

    final http.Response response = await http.get(url);

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);

      return data.map<Product>((product) {
        return Product(
          id: product['id'],
          title: product['title'],
          slug: product['slug'],
          price: (product['price'] as num).toDouble(),
          description: product['description'],
          category: product['category']['name'],
          images: List<String>.from(product['images'] ?? []),
        );
      }).toList();
    } else {
      throw Exception('Erreur lors de la récupération des produits');
    }
  }
}
