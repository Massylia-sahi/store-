import 'package:flutter/material.dart';
import 'package:store/screens/product_details_screen.dart';
import 'package:store/services/category_api_service.dart';
import 'package:store/models/product.dart';

class ProductsByCategoryScreen extends StatelessWidget {
  final int categoryId;

  const ProductsByCategoryScreen({super.key, required this.categoryId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Produits')),
      body: FutureBuilder<List<Product>>(
        future: CategoryApiService().getProductsByCategoryId(categoryId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text('Erreur lors du chargement'));
          }

          final products = snapshot.data!;

          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
                return ListTile(
                  leading: Image.network(product.images.isNotEmpty ? product.images.first : '', width: 60),
                  title: Text(product.title),
                  subtitle: Text('${product.price} €'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProductDetailScreen(product: product),
                      ),
                    );
                  },
                );
            },
          );
        },
      ),
    );
  }
}
