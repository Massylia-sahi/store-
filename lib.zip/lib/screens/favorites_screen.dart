import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:store/providers/favorites_provider.dart';
import 'package:store/models/product.dart';
import 'package:store/services/api_service.dart'; // à créer pour fetch les produits

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  Future<List<Product>> _loadFavoriteProducts(BuildContext context) async {
    final ids = Provider.of<FavoritesProvider>(context, listen: false).favoriteProductIds;
    return ApiService.getProductsByIds(ids); // méthode que tu écriras dans ApiService
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mes Favoris')),
      body: FutureBuilder(
        future: _loadFavoriteProducts(context),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final products = snapshot.data!;
          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (ctx, i) => ListTile(
              title: Text(products[i].title),
              subtitle: Text("${products[i].price} €"),
            ),
          );
        },
      ),
    );
  }
}
